create function btfloat8cmp(double precision, double precision) returns integer
    language internal
as
$$btfloat8cmp$$;

comment on function btfloat8cmp(float8, float8) is 'less-equal-greater';

