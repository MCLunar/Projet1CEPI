create function bytearecv(internal) returns bytea
    language internal
as
$$bytearecv$$;

comment on function bytearecv(internal) is 'I/O';

