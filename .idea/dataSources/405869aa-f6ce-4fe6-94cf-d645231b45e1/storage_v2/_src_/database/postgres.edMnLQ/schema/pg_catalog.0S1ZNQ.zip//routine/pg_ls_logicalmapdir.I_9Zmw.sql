create function pg_ls_logicalmapdir(OUT name text, OUT size bigint, OUT modification timestamp with time zone) returns SETOF record
    language internal
as
$$pg_ls_logicalmapdir$$;

comment on function pg_ls_logicalmapdir(out text, out int8, out timestamptz) is 'list of files in the pg_logical/mappings directory';

