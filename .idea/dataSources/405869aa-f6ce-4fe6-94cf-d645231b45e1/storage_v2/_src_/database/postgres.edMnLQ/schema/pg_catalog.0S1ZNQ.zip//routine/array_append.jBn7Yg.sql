create function array_append(anycompatiblearray, anycompatible) returns anycompatiblearray
    language internal
as
$$array_append$$;

comment on function array_append(anycompatiblearray, anycompatible) is 'append element onto end of array';

