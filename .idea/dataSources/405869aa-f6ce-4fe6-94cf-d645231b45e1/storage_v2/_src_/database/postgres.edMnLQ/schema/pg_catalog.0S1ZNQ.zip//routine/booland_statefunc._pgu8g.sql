create function booland_statefunc(boolean, boolean) returns boolean
    language internal
as
$$booland_statefunc$$;

comment on function booland_statefunc(bool, bool) is 'aggregate transition function';

