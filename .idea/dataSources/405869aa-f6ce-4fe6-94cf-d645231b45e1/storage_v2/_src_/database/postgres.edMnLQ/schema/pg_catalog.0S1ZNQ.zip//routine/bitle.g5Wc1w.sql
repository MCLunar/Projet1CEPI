create function bitle(bit, bit) returns boolean
    language internal
as
$$bitle$$;

comment on function bitle(bit, bit) is 'implementation of <= operator';

