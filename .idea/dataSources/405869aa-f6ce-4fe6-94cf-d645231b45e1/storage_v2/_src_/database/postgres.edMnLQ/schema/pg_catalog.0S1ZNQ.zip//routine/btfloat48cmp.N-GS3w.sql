create function btfloat48cmp(real, double precision) returns integer
    language internal
as
$$btfloat48cmp$$;

comment on function btfloat48cmp(float4, float8) is 'less-equal-greater';

