create function pg_stat_get_recovery_prefetch(OUT stats_reset timestamp with time zone, OUT prefetch bigint, OUT hit bigint, OUT skip_init bigint, OUT skip_new bigint, OUT skip_fpw bigint, OUT skip_rep bigint, OUT wal_distance integer, OUT block_distance integer, OUT io_depth integer) returns SETOF record
    language internal
as
$$pg_stat_get_recovery_prefetch$$;

comment on function pg_stat_get_recovery_prefetch(out timestamptz, out int8, out int8, out int8, out int8, out int8, out int8, out int4, out int4, out int4) is 'statistics: information about WAL prefetching';

