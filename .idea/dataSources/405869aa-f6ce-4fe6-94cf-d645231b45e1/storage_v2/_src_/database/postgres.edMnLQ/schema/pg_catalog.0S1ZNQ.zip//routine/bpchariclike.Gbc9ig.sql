create function bpchariclike(character, text) returns boolean
    language internal
as
$$texticlike$$;

comment on function bpchariclike(bpchar, text) is 'implementation of ~~* operator';

