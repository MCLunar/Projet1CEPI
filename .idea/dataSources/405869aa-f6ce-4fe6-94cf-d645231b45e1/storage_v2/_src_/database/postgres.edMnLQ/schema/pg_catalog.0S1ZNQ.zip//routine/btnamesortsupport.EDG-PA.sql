create function btnamesortsupport(internal) returns void
    language internal
as
$$btnamesortsupport$$;

comment on function btnamesortsupport(internal) is 'sort support';

