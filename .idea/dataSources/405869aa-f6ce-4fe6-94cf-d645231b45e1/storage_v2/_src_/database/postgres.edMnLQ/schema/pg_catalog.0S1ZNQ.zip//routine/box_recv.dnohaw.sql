create function box_recv(internal) returns box
    language internal
as
$$box_recv$$;

comment on function box_recv(internal) is 'I/O';

