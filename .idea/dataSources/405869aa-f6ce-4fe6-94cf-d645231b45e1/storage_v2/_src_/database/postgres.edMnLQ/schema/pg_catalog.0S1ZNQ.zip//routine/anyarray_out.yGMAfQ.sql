create function anyarray_out(anyarray) returns cstring
    language internal
as
$$anyarray_out$$;

comment on function anyarray_out(anyarray) is 'I/O';

