create function atan2d(double precision, double precision) returns double precision
    language internal
as
$$datan2d$$;

comment on function atan2d(float8, float8) is 'arctangent, two arguments, degrees';

