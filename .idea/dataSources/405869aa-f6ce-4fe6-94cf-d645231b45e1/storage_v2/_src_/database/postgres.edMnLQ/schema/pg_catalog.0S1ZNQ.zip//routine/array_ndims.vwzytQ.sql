create function array_ndims(anyarray) returns integer
    language internal
as
$$array_ndims$$;

comment on function array_ndims(anyarray) is 'number of array dimensions';

