create function btoidvectorcmp(oidvector, oidvector) returns integer
    language internal
as
$$btoidvectorcmp$$;

comment on function btoidvectorcmp(oidvector, oidvector) is 'less-equal-greater';

