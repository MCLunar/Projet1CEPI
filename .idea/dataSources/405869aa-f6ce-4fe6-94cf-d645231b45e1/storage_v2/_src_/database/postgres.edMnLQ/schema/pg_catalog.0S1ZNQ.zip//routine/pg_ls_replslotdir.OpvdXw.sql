create function pg_ls_replslotdir(slot_name text, OUT name text, OUT size bigint, OUT modification timestamp with time zone) returns SETOF record
    language internal
as
$$pg_ls_replslotdir$$;

comment on function pg_ls_replslotdir(text, out text, out int8, out timestamptz) is 'list of files in the pg_replslot/slot_name directory';

