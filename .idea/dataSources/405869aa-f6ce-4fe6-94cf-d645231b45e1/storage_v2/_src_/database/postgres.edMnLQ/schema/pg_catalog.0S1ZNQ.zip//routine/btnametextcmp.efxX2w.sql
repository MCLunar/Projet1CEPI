create function btnametextcmp(name, text) returns integer
    language internal
as
$$btnametextcmp$$;

comment on function btnametextcmp(name, text) is 'less-equal-greater';

